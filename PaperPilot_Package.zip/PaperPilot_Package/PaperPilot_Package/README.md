# PaperPilot

논문 PDF의 제목을 자동으로 추출하여 파일명을 정리해주는 Windows 유틸리티 프로그램입니다.  
사용자는 PDF를 드래그 앤 드롭하면, 프로그램이 논문의 제목을 분석하여 파일명을 자동으로 변경합니다.

---

## 1. 개발 목적

논문을 다운로드할 때 파일명이 `download.pdf`, `paper123.pdf` 등으로 저장되는 경우가 많습니다.  
이 프로그램은 PDF 내용을 분석하여 **논문 제목 기반으로 파일명을 자동 정리**함으로써  
논문 관리 효율을 높이기 위해 제작되었습니다.

---

## 2. 실행 환경

- OS: Windows 10 / Windows 11 (64-bit)
- Python: 3.10 이상 권장 (개발 기준: 3.13)
- 인터넷 연결: 최초 패키지 설치 시 필요

---

## 3. 사전 설치 프로그램

### 1) Python 설치
Python: 3.10 이상 권장 (개발 기준: 3.13)
https://www.python.org/downloads/

설치 시 반드시 아래 옵션 체크 (중요):
✔ Add Python to PATH

설치 확인:
powershell에서

python --version
또는
py --version

---

### 2) 필수 패키지 설치 (필수)

python -m pip install pymupdf tkinterdnd2

또는

py -m pip install pymupdf tkinterdnd2

---

## 4. 프로그램 실행 방법

1. 다운받은 파일 내 paperpilot_app.py 프로그램을 PC에 저장.
2. paperpilot_app.py 프로그램의 저장 경로를 통해서 powershell에서 실행.

실행 예시) powershell에서 명령어 : 
python C:\paperpilot_app.py

---

## 5. 사용 방법

1. 프로그램 실행
2. PDF 파일을 드래그 앤 드롭
3. 제목 자동 분석
4. "파일명 변경 실행" 클릭

---

## 6. 주요 기능

- PDF 제목 자동 추출
- 드래그 앤 드롭 지원
- 파일명 자동 변경
- 중복 파일명 처리

---

## 7. 관리자 권한

일반 폴더에서는 필요 없음

---

## 8. 주의사항

- 스캔 PDF는 정확도 낮음
- 일부 논문은 제목 인식 실패 가능

---

## 9. 오류 해결

python 명령이 안 될 경우 → Python 재설치 + PATH 체크

---

## 10. 사용 라이브러리

- PyMuPDF
- tkinter
- tkinterdnd2
